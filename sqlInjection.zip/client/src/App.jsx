import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AdminLogin from "./components/AdminLogin";
import UserRegister from "./components/UserRegistration";
import UserTable from "./components/UserTable";
import DummyTable from "./components/DummyTable";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<AdminLogin />} />
        <Route path="/reg" element={<UserRegister />} />
        <Route path="/user" element={<UserTable />} />
        <Route path="/users" element={<DummyTable/>} />
      </Routes>
    </Router>
  );
};

export default App;

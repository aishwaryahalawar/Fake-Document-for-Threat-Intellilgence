import { useState } from "react";
import Modal from "react-modal";
import UserRegistration from "../components/UserRegistration"; // Import the registration form component

const DummyTable = () => {
  const users=[
    {
      id: 1,
      name: "John Doe",
      email: "johndoe@example.com",
      contactNumber: "1234567890",
      age: 30,
      aadhar: "1234-5678-9012",
      pan: "ABCDE1234F",
      drivingId: "DL1234567890",
      address: "123 Main Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 2,
      name: "Jane Smith",
      email: "janesmith@example.com",
      contactNumber: "9876543210",
      age: 25,
      aadhar: "5678-1234-9012",
      pan: "XYZAB9876P",
      drivingId: "DL9876543210",
      address: "456 Elm Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 3,
      name: "Alice Brown",
      email: "alicebrown@example.com",
      contactNumber: "1111111111",
      age: 28,
      aadhar: "8765-4321-0912",
      pan: "LMNOP5432Q",
      drivingId: "DL1230987654",
      address: "789 Pine Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 4,
      name: "Bob White",
      email: "bobwhite@example.com",
      contactNumber: "2222222222",
      age: 35,
      aadhar: "3456-7890-1234",
      pan: "QWERT9876Y",
      drivingId: "DL4567891234",
      address: "321 Oak Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 5,
      name: "Charlie Green",
      email: "charliegreen@example.com",
      contactNumber: "3333333333",
      age: 40,
      aadhar: "5678-2345-6789",
      pan: "ZXCVB6789M",
      drivingId: "DL7894561230",
      address: "123 Maple Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 6,
      name: "Diana Prince",
      email: "dianaprince@example.com",
      contactNumber: "4444444444",
      age: 29,
      aadhar: "1234-5678-0987",
      pan: "ASDFG4321K",
      drivingId: "DL6543210987",
      address: "456 Cedar Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 7,
      name: "Ethan Hunt",
      email: "ethanhunt@example.com",
      contactNumber: "5555555555",
      age: 38,
      aadhar: "2345-6789-0123",
      pan: "TYUIO8765P",
      drivingId: "DL8765432109",
      address: "789 Birch Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 8,
      name: "Fiona Gray",
      email: "fionagray@example.com",
      contactNumber: "6666666666",
      age: 32,
      aadhar: "3456-7890-2345",
      pan: "HJKLQ4321Z",
      drivingId: "DL5432167890",
      address: "321 Spruce Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 9,
      name: "George Blue",
      email: "georgeblue@example.com",
      contactNumber: "7777777777",
      age: 27,
      aadhar: "4567-8901-3456",
      pan: "BNMVC8765R",
      drivingId: "DL0987654321",
      address: "123 Aspen Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 10,
      name: "Hannah Yellow",
      email: "hannahyellow@example.com",
      contactNumber: "8888888888",
      age: 26,
      aadhar: "5678-9012-4567",
      pan: "GHJKP9876T",
      drivingId: "DL8765123409",
      address: "456 Willow Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
  ];

  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);

  const handleViewUser = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const openAddUserModal = () => {
    setIsAddUserModalOpen(true);
  };

  const closeAddUserModal = () => {
    setIsAddUserModalOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-gray-100 p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">User Details</h2>

      

      <table className="table-auto w-full max-w-4xl bg-white shadow-lg rounded-lg overflow-hidden">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2">Name</th>
            <th className="px-4 py-2">Email</th>
            <th className="px-4 py-2">Contact Number</th>
            <th className="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id} className="border-t">
              <td className="px-4 py-2">{user.name}</td>
              <td className="px-4 py-2">{user.email}</td>
              <td className="px-4 py-2">{user.contactNumber}</td>
              <td className="px-4 py-2">
                <button
                  onClick={() => handleViewUser(user)}
                  className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition"
                >
                  View
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedUser && (
        <Modal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto mt-20"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center"
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">User Details</h3>
          <p>
            <strong>Name:</strong> {selectedUser.name}
          </p>
          <p>
            <strong>Email:</strong> {selectedUser.email}
          </p>
          <p>
            <strong>Contact Number:</strong> {selectedUser.contactNumber}
          </p>
          <p>
            <strong>Age:</strong> {selectedUser.age}
          </p>
          <p>
            <strong>Aadhar:</strong> {selectedUser.aadhar}
          </p>
          <p>
            <strong>PAN:</strong> {selectedUser.pan}
          </p>
          <p>
            <strong>Driving ID:</strong> {selectedUser.drivingId}
          </p>
          <p>
            <strong>Address:</strong> {selectedUser.address}
          </p>
          <p>
            <strong>Profile Picture:</strong>
            <img
              src={selectedUser.profilePictureUrl}
              alt="Profile"
              className="mt-2 w-20 h-20 rounded-full"
            />
          </p>
          <button
            onClick={closeModal}
            className="mt-4 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition"
          >
            Close
          </button>
        </Modal>
      )}

      {isAddUserModalOpen && (
        <Modal
          isOpen={isAddUserModalOpen}
          onRequestClose={closeAddUserModal}
          className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto mt-20"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center"
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">Add New User</h3>
          <UserRegistration onClose={closeAddUserModal} />
        </Modal>
      )}
    </div>
  );
};

export default DummyTable;

import React, { useState } from "react";
import axios from "axios";
import api from "../service/api";

const UserRegister = ({ onClose }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    contactNumber: "",

    age: "",
    aadhar: "",
    pan: "",
    drivingId: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post("/user/", formData);
      onClose();
      alert(res.data.message);
    } catch (err) {
      console.log(err);
      alert(err.response?.data?.message || "An error occurred");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-md p-8 rounded-lg shadow-lg bg-white bg-opacity-70 backdrop-blur">
        <h2 className="text-2xl font-bold text-gray-800 text-center mb-6">
          User Registration
        </h2>
        <form onSubmit={handleSubmit} className="flex flex-col">
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            name="contactNumber"
            placeholder="Contact Number"
            value={formData.contactNumber}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="number"
            name="age"
            placeholder="Age"
            value={formData.age}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            name="aadhar"
            placeholder="Aadhar ID"
            value={formData.aadhar}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            name="pan"
            placeholder="PAN ID"
            value={formData.pan}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="text"
            name="drivingId"
            placeholder="Driving License ID"
            value={formData.drivingId}
            onChange={handleChange}
            className="border border-gray-300 rounded-md mb-4 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            className="bg-blue-500 text-white px-4 py-3 rounded-md hover:bg-blue-600 transition"
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default UserRegister;

import  { useState, useEffect } from "react";
import Modal from "react-modal";
import api from "../service/api";
import UserRegistration from "../components/UserRegistration"; // Import the registration form component

const UserTable = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);

  const dummyData = [
    {
      id: 1,
      name: "John Doe",
      email: "johndoe@example.com",
      contactNumber: "1234567890",
      age: 30,
      aadhar: "1234-5678-9012",
      pan: "ABCDE1234F",
      drivingId: "DL1234567890",
      address: "123 Main Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
    {
      id: 2,
      name: "Jane Smith",
      email: "janesmith@example.com",
      contactNumber: "9876543210",
      age: 25,
      aadhar: "5678-1234-9012",
      pan: "XYZAB9876P",
      drivingId: "DL9876543210",
      address: "456 Elm Street",
      profilePictureUrl: "https://via.placeholder.com/150",
    },
  ];

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("/user");
        console.log(res.data);

        if (Array.isArray(res.data) && res.data.length > 0) {
          setUsers(res.data);
        } else {
          setUsers(dummyData);
        }
      } catch (err) {
        console.error("Error fetching users:", err);
        setUsers(dummyData);
      }
    };

    fetchUsers();
  }, []);

  const handleViewUser = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const openAddUserModal = () => {
    setIsAddUserModalOpen(true);
  };

  const closeAddUserModal = () => {
    setIsAddUserModalOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-gray-100 p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">User Details</h2>

      

      <table className="table-auto w-full max-w-4xl bg-white shadow-lg rounded-lg overflow-hidden">
        <thead className="bg-gray-200">
          <tr>
            <th className="px-4 py-2">Name</th>
            <th className="px-4 py-2">Email</th>
            <th className="px-4 py-2">Contact Number</th>
            <th className="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users &&
            users.map((user) => (
              <tr key={user.id} className="border-t">
                <td className="px-4 py-2">{user.name}</td>
                <td className="px-4 py-2">{user.email}</td>
                <td className="px-4 py-2">{user.contactNumber}</td>
                <td className="px-4 py-2">
                  <button
                    onClick={() => handleViewUser(user)}
                    className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition"
                  >
                    View
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>

      {selectedUser && (
        <Modal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto mt-20"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center"
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">User Details</h3>
          <p>
            <strong>Name:</strong> {selectedUser.name}
          </p>
          <p>
            <strong>Email:</strong> {selectedUser.email}
          </p>
          <p>
            <strong>Contact Number:</strong> {selectedUser.contactNumber}
          </p>
          <p>
            <strong>Age:</strong> {selectedUser.age}
          </p>
          <p>
            <strong>Aadhar:</strong> {selectedUser.aadhar}
          </p>
          <p>
            <strong>PAN:</strong> {selectedUser.pan}
          </p>
          <p>
            <strong>Driving ID:</strong> {selectedUser.drivingId}
          </p>
          <p>
            <strong>Address:</strong> {selectedUser.address}
          </p>
          <p>
            <strong>Profile Picture:</strong>
            <img
              src={selectedUser.profilePictureUrl}
              alt="Profile"
              className="mt-2 w-20 h-20 rounded-full"
            />
          </p>
          <button
            onClick={closeModal}
            className="mt-4 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 transition"
          >
            Close
          </button>
        </Modal>
      )}

      {isAddUserModalOpen && (
        <Modal
          isOpen={isAddUserModalOpen}
          onRequestClose={closeAddUserModal}
          className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto mt-20"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center"
        >
          <h3 className="text-xl font-bold text-gray-800 mb-4">Add New User</h3>
          <UserRegistration onClose={closeAddUserModal} />
        </Modal>
      )}
    </div>
  );
};

export default UserTable;

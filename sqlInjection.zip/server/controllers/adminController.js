// /controllers/adminController.js
const pool = require("../DB/DBConection");

exports.createAdmin = async (req, res) => {
  const { name, email, password } = req.body;
  try {
    await pool.execute(
      "INSERT INTO admins (name, email, password) VALUES (?, ?, ?)",
      [name, email, password]
    );
    res.status(201).json({ message: "Admin created successfully!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.getAllAdmins = async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT * FROM admins");
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
exports.getAdmin = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await pool.execute("SELECT * FROM admins WHERE id = ?", [
      id,
    ]);
    res.status(200).json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateAdmin = async (req, res) => {
  const { id } = req.params;
  const { name, email, password } = req.body;
  try {
    await pool.execute(
      "UPDATE admins SET name = ?, email = ?, password = ? WHERE id = ?",
      [name, email, password, id]
    );
    res.status(200).json({ message: "Admin updated successfully!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteAdmin = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.execute("DELETE FROM admins WHERE id = ?", [id]);
    res.status(200).json({ message: "Admin deleted successfully!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const sendAlertEmail = require("../utils/sendAlertEmail");
const requestIp = require("request-ip");

const sqlInjectionMiddleware = (req, res, next) => {
  const suspiciousPatterns = [
    /\b(SELECT|INSERT|UPDATE|DELETE|DROP|--|;|UNION|OR|AND)\b/i,
    /[\'\"\\\/\*]/g,
    /(\b(OR|AND)\b.*\d=\d)/g,
    /\b(SELECT|INSERT|UPDATE|DELETE|DROP)\s+\*.*\b/i,
  ];

  const isInjection = (data) => {
    if (!data || typeof data !== "object") return false;
    return Object.values(data).some((value) =>
      suspiciousPatterns.some((pattern) => pattern.test(String(value)))
    );
  };

  const isBodyInjection = isInjection(req.body);
  const isQueryInjection = isInjection(req.query);

  if (isBodyInjection || isQueryInjection) {
    // Get the client IP
    const clientIp =
      requestIp.getClientIp(req) || // Try to get IP from headers
      req.headers["x-forwarded-for"] || // Common proxy header
      req.connection.remoteAddress || // Direct connection
      req.socket.remoteAddress || // Raw socket
      "Unknown IP"; // Fallback

    sendAlertEmail(req, clientIp);
    return res
      .status(400)
      .json({ error: "Potential SQL Injection attempt detected!" });
  }
  next(); // Continue to the next middleware if no injection is detected
};

module.exports = sqlInjectionMiddleware;

// /routes/adminRoutes.js
const express = require("express");
const router = express.Router();
const {
  createAdmin,
  getAdmin,
  updateAdmin,
  deleteAdmin,
  getAllAdmins,
} = require("../controllers/adminController");

// Admin CRUD Routes
router.post("/", createAdmin);
router.get("/", getAllAdmins);
router.get("/:id", getAdmin);
router.put("/:id", updateAdmin);
router.delete("/:id", deleteAdmin);

module.exports = router;

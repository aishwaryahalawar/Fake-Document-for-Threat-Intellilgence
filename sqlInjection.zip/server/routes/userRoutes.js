// /routes/userRoutes.js
const express = require("express");
const router = express.Router();
const {
  createUser,
  getUser,
  updateUser,
  deleteUser,
  getAllUsers,
} = require("../controllers/userController");

// User CRUD Routes
router.post("/", createUser);
router.get("/:id", getUser);
router.get("/", getAllUsers);
router.put("/:id", updateUser);
router.delete("/:id", deleteUser);

module.exports = router;

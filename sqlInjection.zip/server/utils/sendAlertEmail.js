const nodemailer = require("nodemailer");

const sendAlertEmail = (req, clientIp) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.ADMIN_EMAIL,
      pass: process.env.ADMIN_PASSWORD,
    },
  });

  const mailOptions = {
    from: process.env.ADMIN_EMAIL,
    to: process.env.ADMIN_EMAIL,
    subject: "SQL Injection Attempt Detected",
    text: `Suspicious activity detected:

Client IP: ${clientIp == "::1" ? "127.0.0.1" : clientIp}
Request Body: ${JSON.stringify(req.body, null, 2)}
Request Query: ${JSON.stringify(req.query, null, 2)}
Time: ${new Date().toISOString()}`,
  };

  transporter.sendMail(mailOptions, (error) => {
    if (error) {
      console.error("Error sending email:", error);
    } else {
      console.log("Alert email sent to admin.");
    }
  });
};

module.exports = sendAlertEmail;
